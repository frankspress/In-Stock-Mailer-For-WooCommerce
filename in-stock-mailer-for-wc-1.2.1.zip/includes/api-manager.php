<?php

if ( ! defined( 'ABSPATH' ) ) exit;


class apiManager extends inStockManager {

  public function __construct() {
    $this->add_alert_route();
    $this->remove_alert_route();
    $this->remove_bulk_alert_route();
    $this->remove_sent_email_route();
    $this->send_test_email_route();
  }

  /**
   * Public Routes
   */
  public function add_alert_route() {
    add_action('rest_api_init', function () {
      register_rest_route( 'in-stock-mailer/v1', 'product/(?P<product_id>\d+)',array(
                    'methods'  => 'POST',
                    'callback' => array( $this, 'add_alert_request' ),
                    'args' => [
                         'product_id' => [
                             'validate_callback' => function($product_id) {
                                     return get_post($product_id) ? true : false;
                                 },
                         ]
                     ],
                     'permission_callback' => array( $this, 'validate_payload' )
          ));
    });
  }

  public function remove_alert_route() {
    add_action('rest_api_init', function () {
      register_rest_route( 'in-stock-mailer/v1', 'product/remove/(?P<product_id>\d+)',array(
                    'methods'  => 'DELETE',
                    'callback' => array( $this, 'remove_alert_request' ),
                    'args' => [
                         'product_id' => [
                             'validate_callback' => function($product_id) {
                                     return get_post($product_id) ? true : false;
                                 },
                         ],
                     ],
                     'permission_callback' => array( $this, 'validate_payload' )
          ));
    });
  }
  /**
   * Admin Routes
   */
  public function remove_bulk_alert_route() {
    add_action('rest_api_init', function () {
      register_rest_route( 'in-stock-mailer/v1', 'requests/remove',array(
                    'methods'  => 'DELETE',
                    'callback' => array( $this, 'remove_request_by_ids' ),
                    'permission_callback' => array( $this, 'validate_request_ids' )
          ));
    });
  }

  public function remove_sent_email_route() {
    add_action('rest_api_init', function () {
      register_rest_route( 'in-stock-mailer/v1', 'email/remove/(?P<email_id>\d+)',array(
                    'methods'  => 'DELETE',
                    'callback' => array( $this, 'remove_sent_email' ),
                        'args' => [
                             'email_id' => [
                                 'validate_callback' => function($email_id) {
                                         return is_numeric($email_id);
                                     },
                             ],
                         ],
                    'permission_callback' => function ($request) {
                            if ( !current_user_can( 'manage_options') ) return false;
                              if ( $request['email_id'] = filter_var($request['email_id'], FILTER_VALIDATE_INT ) )  {
                                  return true;
                                }
                            return false;
                            },
          ));
     });
  }


  public function send_test_email_route() {
    add_action('rest_api_init', function () {
      register_rest_route( 'in-stock-mailer/v1', 'email-test/',array(
                    'methods'  => 'POST',
                    'callback' => array( $this, 'send_test_email' ),
                    'permission_callback' => array( $this, 'test_email_permission_validate' )
          ));
    });
  }

  /**
   * Methods
   */
  public function get_user_email($email = '') {
      $current_user = wp_get_current_user();
      if ( $current_user && get_current_user_id() ) {
        return $current_user->user_email;
      }
      if ( !empty( $email ) && email_exists( $email ) ) {
        return false;
      }
      if ( !empty($email) ) {
        return $email;
      }
      if ( isset($_COOKIE['reference_email'])) {
          return unserialize(base64_decode($_COOKIE['reference_email']), ["allowed_classes" => false]);
      }
      return $email;
  }

  public function set_user_email($email) {
       setcookie('reference_email', base64_encode(serialize($email)), (time() + 8419200), "/");
  }

  public function validate_email($email) {
    $getEmail = sanitize_email( $this->get_user_email($email) );
    if ( $getEmail && is_email( $getEmail ) ) {
       $this->set_user_email($getEmail);
       return $getEmail;
    }
    return false;
  }

  public function validate_payload( $request ) {
    $email = !empty($request['email']) ? $request['email'] : '';
    $email = $this->validate_email($email);
    // Checks if email is valid and honeypot field was sent and it is empty
    if ( $email && ( isset( $request['hname'] ) && empty( $request['hname'] ) ) ) {
        $request['email'] = $email;
        return true;
    }
    return false;
  }

  public function validate_request_ids( $request ) {
    if ( !current_user_can( 'manage_options') ) return false;
      if ( !empty($request['request_ids']) && is_string($request['request_ids']) ) {
        $ids = explode('-', $request['request_ids'] );
        $request['request_ids'] = $ids;
        return true;
      }
      return false;
  }

  public function remove_request_by_ids( WP_REST_Request $data ) {
    global $wpdb, $table_prefix;
    $request_ids = $data['request_ids'];

    $tblname = self::table_name;
    $wp_table = $table_prefix . $tblname;

    $plc_hold = '';
    foreach ($request_ids as $id) {
        $plc_hold .= '%d,';
    }
    $plc_hold = rtrim($plc_hold, ',');

    $sql = " DELETE FROM $wp_table WHERE id IN(" . $plc_hold . ") ";
    $sql = $wpdb->prepare( $sql, $request_ids );
    $wpdb->query($sql);
    return array('action'=> 'remove');
  }

  public function add_alert_request( WP_REST_Request $data) {
      global $wpdb, $table_prefix;
      $product_id = $data['product_id'];
      $email = $data['email'];

      $tblname = self::table_name;
      $wp_table = $table_prefix . $tblname;

      $sql = "INSERT INTO $wp_table ( product_id, email, sent_id ) VALUES ( %d, %s, null ) ON DUPLICATE KEY UPDATE product_id = %d";
      $sql = $wpdb->prepare( $sql, $product_id, $email, $product_id );
      $wpdb->query($sql);
      return array('action'=> 'add');
  }

  public function remove_alert_request( WP_REST_Request $data) {
      global $wpdb, $table_prefix;
      $product_id = $data['product_id'];
      $email = $data['email'];

      $tblname = self::table_name;
      $wp_table = $table_prefix . $tblname;

      $sql = "DELETE FROM $wp_table WHERE product_id = %d AND email =  %s AND sent_id IS NULL ";
      $sql = $wpdb->prepare( $sql, $product_id, $email );
      $wpdb->query($sql);
      return array('action'=> 'remove');
  }

  public function remove_sent_email(WP_REST_Request $data) {
    global $wpdb, $table_prefix;
    $tblname = self::email_table_name;
    $wp_email_table = $table_prefix . $tblname;
    $id = $data['email_id'];
    $sql = $wpdb->prepare( " DELETE FROM $wp_email_table WHERE id = %d ", array( $id ) );
    $wpdb->query( $sql );
    return array('action'=> 'remove');
  }

  public function test_email_permission_validate( $request ) {
    if ( !current_user_can( 'manage_options') ) return false;
    $email = !empty($request['test_email']) ? $request['test_email'] : '';
    $request['test_email'] = sanitize_email( $email );
    if ( is_email($request['test_email']) ) {
        return true;
    }
    return false;
  }

  public function send_test_email( WP_REST_Request $data ) {

    // Create a self mock user from email list to feed to send_email
    // User must be admin and able to manage_options therefore must exist to send the mock email.
    $mock_requester = new stdClass();
    $mock_requester->user_name = wp_get_current_user()->user_login;
    $mock_requester->email = $data['test_email'];

    // Generate a random list of products
    global $wpdb;
    $products_merge = $wpdb->get_results( "  SELECT wp_posts.id as product_id , wp_posts.post_title as product_name
                                             FROM wp_posts
                                             INNER JOIN wp_postmeta ON ( wp_posts.id = wp_postmeta.post_id)
                                             WHERE wp_posts.post_type = 'product' AND wp_postmeta.meta_value = 'instock'
                                             ORDER BY RAND() LIMIT 3 ");
    wp_reset_postdata();
    // Merge products to $emailList defaults
    $container = array();
    if ( !empty( $products_merge ) ) {
      foreach ($products_merge as $row => $result ) {
          $container[$result->product_id] = $result->product_name;
      }
    }
    // Add property to class
    $mock_requester->products_merge = $container;

    // Send Test Email (Inherited class)
    return $this->send_email( $mock_requester );
  }
}

new apiManager();


?>
