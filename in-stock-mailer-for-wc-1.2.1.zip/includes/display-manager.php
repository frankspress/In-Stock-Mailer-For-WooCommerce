<?php

if ( ! defined( 'ABSPATH' ) ) exit;


class displayManager extends apiManager {

    private $variations;
    private $options;

    function __construct() {
        // Gets plugin options
        $this->options = get_option( 'ism_stock_alert_options', ism_default_values() );
    }

    public function add_action_button() {
      // For simple products
      add_action( 'woocommerce_simple_add_to_cart', array($this,'display_notification_btn'), $priority = 31);
      // For variations
      add_action( 'woocommerce_after_add_to_cart_form', array($this,'display_notification_btn'), $priority = 31);
    }

    public function get_user_option( $option_name ) {
      return isset( $this->options[$option_name] ) ? $this->options[$option_name] : '';
    }

    public function generate_alert_form_simple() {

      $user_has_alert = $this->user_has_alert_simple();

      $alert_form = '<form id="in-stock-form" action="">';
      if ( get_current_user_id() ) {
          $alert_form  .= '<a class="instock-notify notify-btn '. ( $user_has_alert ? 'instock-hidden"' : '"' );
          $alert_form  .= ' href="#"><i class="fas fa-bell"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text') ).'<div class="loader"></div></a>';
          $alert_form  .= '<a class="instock-notification notify-btn '. ( !$user_has_alert ? 'instock-hidden"' : '"' );
          $alert_form  .= ' href="#"><i class="fas fa-envelope"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text_cancel') ).'<div class="loader loader-cancel"></div><br>';
          $alert_form  .= $this->get_user_option('ism_button_cancel_active') ? '<span class="cancel-instock">cancel?</span></a>' : '</a>';
      } else {
          $alert_form  .= '<a class="instock-notify-email notify-btn '. ( $user_has_alert ? 'instock-hidden"' : '"' );
          $alert_form  .= ' href="#"><i class="fas fa-bell"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text') ).'<div class="loader"></div></a>';
          $alert_form  .= '<a class="instock-notification notify-btn '. ( !$user_has_alert ? 'instock-hidden"' : '"' );
          $alert_form  .= ' href="#"><i class="fas fa-envelope"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text_cancel') ).'<div class="loader loader-cancel"></div><br>';
          $alert_form  .= $this->get_user_option('ism_button_cancel_active') ? '<span class="cancel-instock">cancel?</span></a>' : '</a>';
          $alert_form  .= '<div class="instock-input-section"><input class="hidden-in-stock-field instock-email in-stock-email" style="display:none;" ';
          $alert_form  .= ' value="'.esc_attr( $this->get_user_email() ).'" type="email" placeholder="Your email" name="in-stock-email" required>';
          $alert_form  .= '<input class="hidden-in-stock-field instock-submit" style="display:none;" type="submit" value="Submit"></div>';
      }
      // Let's add a honeypot field..
      $alert_form .= '<input class="its-all-about-honey" type="text" name="hname" placeholder="Your name here">';
      $alert_form .= '</form>';
      return $alert_form;
    }

    public function generate_alert_form_variations() {
      $alert_form = '';
      foreach ($this->variations as $variation) {

          if ( ! $variation['is_in_stock'] &&
                   $variation['is_purchasable'] &&
                     $variation['variation_is_active'] &&
                       $variation['variation_is_visible'] ) {

                         $user_has_alert = $this->user_has_alert_variation($variation['variation_id']);

                         $alert_form .= '<form id="form-variation-id-'. esc_attr( $variation['variation_id'] );
                         $alert_form .= '" data-variation-id="'.esc_attr( $variation['variation_id'] ).'" class="in-stock-form isa-form-hidden" action=""  >';
                         if ( get_current_user_id() ) {
                             $alert_form  .= '<a class="instock-notify notify-btn '. ( $user_has_alert ? 'instock-hidden"' : '"' );
                             $alert_form  .= ' href="#"><i class="fas fa-bell"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text') ).'<div class="loader"></div></a>';
                             $alert_form  .= '<a class="instock-notification notify-btn '. ( !$user_has_alert ? 'instock-hidden"' : '"' );
                             $alert_form  .= ' href="#"><i class="fas fa-envelope"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text_cancel') ).'<div class="loader loader-cancel"></div><br>';
                             $alert_form  .= $this->get_user_option('ism_button_cancel_active') ? '<span class="cancel-instock">cancel?</span></a>' : '</a>';
                         } else {
                             $alert_form  .= '<a class="instock-notify-email notify-btn '. ( $user_has_alert ? 'instock-hidden"' : '"' );
                             $alert_form  .= ' href="#"><i class="fas fa-bell"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text') ).'<div class="loader"></div></a>';
                             $alert_form  .= '<a class="instock-notification notify-btn '. ( !$user_has_alert ? 'instock-hidden"' : '"' );
                             $alert_form  .= ' href="#"><i class="fas fa-envelope"></i>&nbsp; '.esc_html( $this->get_user_option('ism_button_text_cancel') ).'<div class="loader loader-cancel"></div><br>';
                             $alert_form  .= $this->get_user_option('ism_button_cancel_active') ? '<span class="cancel-instock">cancel?</span></a>' : '</a>';
                             $alert_form  .= '<div class="instock-input-section"><input class="hidden-in-stock-field instock-email in-stock-email" style="display:none;" ';
                             $alert_form  .= ' value="'.esc_attr( $this->get_user_email() ).'" type="email" placeholder="Your email" name="in-stock-email" required>';
                             $alert_form  .= '<input class="hidden-in-stock-field instock-submit" style="display:none;" type="submit" value="Submit"></div>';
                         }
                         // Let's add a honeypot field..
                         $alert_form .= '<input class="its-all-about-honey" type="text" name="hname" placeholder="Your name here">';
                         $alert_form .= '</form>';

                       }
      }

      return $alert_form;
    }

    public function user_has_alert_variation( $variation_id ) {
      $user_has_email = $this->get_user_email();

      if ( $user_has_email ) {
        global $wpdb, $table_prefix;
        $tblname = self::table_name;
        $wp_table = $table_prefix . $tblname;

        $sql = "SELECT id FROM $wp_table WHERE product_id =  %d AND email = %s AND sent_id IS NULL ";
        $sql = $wpdb->prepare( $sql, $variation_id, $user_has_email );

        return $wpdb->query($sql);
      }
      return false;
    }

    public function user_has_alert_simple() {
      $user_has_email = $this->get_user_email();
      $product_id = get_the_ID();

      if ( $user_has_email ) {
        global $wpdb, $table_prefix;
        $tblname = self::table_name;
        $wp_table = $table_prefix . $tblname;

        $sql = "SELECT id FROM $wp_table WHERE product_id =  %d AND email = %s AND sent_id IS NULL ";
        $sql = $wpdb->prepare( $sql, $product_id, $user_has_email );

        return $wpdb->query($sql);
      }
      return false;
    }

    public function display_notification_btn() {
 
         $product = wc_get_product( get_the_ID() );
         if (! $product->is_in_stock() ) {

            if ( ! $product->is_type( 'variable' ) ||
                   ( $product->is_type( 'variable' ) && ! $this->get_user_option('ism_button_individual_variation') ) ) {

                      echo $this->generate_alert_form_simple();
                   }
         }
         if( $product->is_type( 'variable' ) &&  $this->get_user_option('ism_button_individual_variation') ) {

                   $this->variations = $product->get_available_variations();
                   echo $this->generate_alert_form_variations();
         }

    }

}

add_action( 'wp', function() {
    if ( is_product() ) {
        $display_manager = new displayManager();
        $display_manager->add_action_button();
    }
});

?>
