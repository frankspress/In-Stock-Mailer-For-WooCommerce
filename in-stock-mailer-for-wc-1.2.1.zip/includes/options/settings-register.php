<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once(ISM_PATH . '/includes/options/setting-pages/general-settings.php' );
require_once(ISM_PATH . '/includes/options/setting-pages/pending-alerts.php' );
require_once(ISM_PATH . '/includes/options/setting-pages/sent-alerts.php' );

function ism_register_option_menu_page() {

    $submenu = add_submenu_page(
          'options-general.php',
          'In Stock Mailer Settings',
          'In Stock Mailer WC',
          'manage_options',
          'in-stock-mailer',
          'ism_display_setting_page'
      );

    // Enqueues script/style on Plugin Menu
    add_action('admin_print_scripts-' . $submenu, function() {
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_style( 'out-of-stock', ISM_URL_PATH . '/includes/options/css/out-of-stock-admin.css');
        wp_enqueue_script( 'out-of-stock-admin', ISM_URL_PATH . '/includes/options/js/out-of-stock-admin.js',  array('jquery', 'wp-color-picker'), 1.0, true);
        wp_localize_script( 'out-of-stock-admin', 'alertDataAdmin', array(
          'api_base_url' => esc_url_raw( rest_url('in-stock-mailer/v1') ),
          'nonce' => wp_create_nonce( 'wp_rest' )
        ) );
    });

    // Enqueues script/style on WooCommerce Menu 
    add_action('admin_print_scripts-woocommerce_page_wc-settings', function() {
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_style( 'out-of-stock', ISM_URL_PATH . '/includes/options/css/out-of-stock-admin.css');
        wp_enqueue_script( 'out-of-stock-admin', ISM_URL_PATH . '/includes/options/js/out-of-stock-admin.js',  array('jquery', 'wp-color-picker'), 1.0, true);
        wp_localize_script( 'out-of-stock-admin', 'alertDataAdmin', array(
          'api_base_url' => esc_url_raw( rest_url('in-stock-mailer/v1') ),
          'nonce' => wp_create_nonce( 'wp_rest' )
        ) );
    });

}
add_action( 'admin_menu', 'ism_register_option_menu_page' );


function ism_register_settings() {

  register_setting(
          'ism_stock_alert_options',
          'ism_stock_alert_options',
          'ism_validate_options' );

  ism_add_general_settings();

}
add_action( 'admin_init', 'ism_register_settings' );


function ism_add_settings_link( array $links ) {
    $url = get_admin_url() . "options-general.php?page=in-stock-mailer";
    $settings_link = '<a href="' . $url . '">' . __('Settings', ISM_DOMAIN) . '</a>';
    $links[] = $settings_link;
    return $links;
  }
add_filter( 'plugin_action_links_' . plugin_basename( ISM_FILE_PATH ), 'ism_add_settings_link' );

?>
