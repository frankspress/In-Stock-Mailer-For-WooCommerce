<?php

if ( ! defined( 'ABSPATH' ) ) exit;

function ism_stock_alert_js() {

    if ( is_product() ) {

      $display_manager = new displayManager();
      $product = wc_get_product( get_the_ID() );
      $is_variation = $product->is_type( 'variable' );
      $is_variation_button_active = $display_manager->get_user_option('ism_button_individual_variation');

    	wp_enqueue_script( 'out-of-stock', ISM_URL_PATH . '/assets/js/out-of-stock.js',  array('jquery'), 1.0, true);
      wp_localize_script( 'out-of-stock', 'alertData', array(
        'api_base_url' => esc_url_raw( rest_url('in-stock-mailer/v1') ),
        'product_id' => esc_attr( get_the_ID() ),
        'is_variation' => rest_sanitize_boolean( $is_variation ),
        'is_variation_button_active' => rest_sanitize_boolean( $is_variation_button_active ),
        'nonce' => wp_create_nonce( 'wp_rest' ),
        'is_user_registered' => esc_attr( get_current_user_id() )
      ) );

      wp_enqueue_style( 'out-of-stock-style', ISM_URL_PATH . '/assets/css/out-of-stock.css');
      $bg_color = $display_manager->get_user_option('ism_button_color');
      $text_color = $display_manager->get_user_option('ism_button_text_color');
      $custom_css = ".notify-btn { background-color: ".esc_attr( $bg_color )."; color: ".esc_attr( $text_color )."; }";
      wp_add_inline_style( 'out-of-stock-style', $custom_css );

    }
}
add_action( 'wp_enqueue_scripts', 'ism_stock_alert_js', 30 );

?>
