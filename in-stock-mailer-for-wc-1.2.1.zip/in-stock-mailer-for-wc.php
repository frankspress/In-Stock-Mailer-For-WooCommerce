<?php
/**
 * Plugin Name: In Stock Mailer for WooCommerce
 * Plugin URI: https://frankspress.com/
 * Description: Sends in stock email alert to requesting customers. It adds a customizable button on the product page.
 * Author: Frank Pagano
 * Author URI: https://frankspress.com
 * Text Domain: in-stock-mailer-wc
 * Version: 1.2.1
 * Copyright (c) 2020 Frankspress
 * License: GPLv2 or later
 *
 * If you don't have a copy of the license please go to <http://www.gnu.org/licenses/>.
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit;
// If WooCommerce is not active do nothing.
if ( ! in_array('woocommerce/woocommerce.php', get_option( 'active_plugins') ) ) {
  return;
}

define( 'ISM_VERSION', '1.2.0' );
define( 'ISM_DOMAIN', 'ism_for_wc' );
define( 'ISM_FILE_PATH', __FILE__ );
define( 'ISM_PATH', plugin_dir_path( __FILE__ ) );
define( 'ISM_URL_PATH', plugin_dir_url( __FILE__ ) );

/**
 * GENERAL HELPERS
 */
require_once(ISM_PATH . '/includes/functions.php' );

/**
 * IN STOCK PRODUCT MANAGER
 */
require_once(ISM_PATH . '/includes/in-stock-manager.php' );

/**
 * CRON MANAGER
 */
require_once(ISM_PATH . '/includes/cron-manager.php' );

/**
 * API MANAGER
 */
require_once(ISM_PATH . '/includes/api-manager.php' );

/**
 * DISPLAY MANAGER
 */
require_once(ISM_PATH . '/includes/display-manager.php' );

/**
 * ENQUEUE SCRIPTS
 */
require_once(ISM_PATH . '/includes/enqueue-manager.php' );



if ( is_admin() ) {

   /**
    * PLUGIN SETTINGS
    */
   require_once(ISM_PATH . '/includes/options/callbacks.php' );
   require_once(ISM_PATH . '/includes/options/option-validate.php' );
   require_once(ISM_PATH . '/includes/options/settings-register.php' );
   require_once(ISM_PATH . '/includes/options/settings-display.php' );
   require_once(ISM_PATH . '/includes/options/settings-woo-display.php' );

   /**
    * ACTIVATION MANAGER
    */
   require_once(ISM_PATH . '/includes/activation-manager.php' );

}


?>
