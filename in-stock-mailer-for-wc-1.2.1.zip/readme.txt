=== In Stock Mailer for WooCommerce ===
Contributors: frankspress
Donate link: https://paypal.me/frankspress
Tags: instock, woocommerce, email, shop, products, storefront, mailer
Requires at least: 4.9
Tested up to: 5.3.2
Stable tag: 1.2.1
WC requires at least: 3.5
WC tested up to: 4.0.1
Requires PHP: 5.6.40
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

In Stock Mailer for WC automatizes the process of sending in stock alert emails to customers with customizable alert button and content.

== Description ==
<h4>Introduction</h4>
<p>Thank you for trying In Stock Mailer for WooCommerce!</p>
This WooCommerce extension allows your online store to have a customizable in stock alert button and email. If a product or product variation is out of stock this plugin will display an animated button with a "Notify when available" option.
Registered users can simply click on the button and will be automatically notified by email when the product/s is back in stock.
<p>For optimal customer experience, non-registered users/visitors will be prompted to enter their email address only once since it will be saved in a cookie; Once a product or more products become available, the application will check and group the requests by email address, and send one email per customer, including images and links to the product pages they were initially interested in.</p>
<p>In the admin pages you can see the pending alert requests and email sent to customers, sort by date, users and status or group requests by email address. You can also customize your back in stock email, which will always begin with "Hello {customer name},"; You can choose a custom header image that shows in the top of the email, a custom subject and even modify the body of the email.</p>
<h4>Notes</h4>
<p>It's important to understand that this plugin uses cookies. It's your responsibility to abide any laws and regulations within your country or jurisdiction ( eg. EU Cookie laws ).</p>

== Installation ==
<h4>To install</h4>
<p>
1. Upload the plugin files to the `/wp-content/plugins` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Settings->In Stock Mailer for WC screen to configure the plugin
4. Set up your button text and email header image.
5. Test your email functionality at the bottom of the General Settings page.
</p>
<h4>Note</h4>
<p>In order for this plugin to work you need a "transactional emails service". Basically your WordPress installation should be set-up to send individual emails.</p>

== Frequently Asked Questions ==

= Do I have to configure anything to use it? =
Yes and no. The plugin works out of the box but you should add an header image to your email.

= When are the in stock email alerts sent? =
Normally it runs at intervals of 8 hours. If your website has a low traffic rate consider adding a server based cron job.

= Is there any extra futures? =
At the moment there isn't any paid option available. Depending on requests and feedbacks I will be happy to add new free features in the future! Please hit me up with suggestions.

= The plugin isn't sending any email, what do I do? =
If emails are not being sent the first step is to send an email test. You can do so from the General Settings page. This plugin requires you to have a transactional email service in place already!

= What is a transactional mail service? =
It's a service offered by a company that allows WordPress to send "individual emails". There are many out there such as SendGrid, mailgun etc.; Some of which have free plans too.

= Will I get spam requests? =
The plugin offers some degree of protection against spam! Bots will have a hard time sending fake requests but some may get through. In the future I might implement captcha if needed/requested.

== Screenshots ==

1. Notification button.
1. General settings menu.
1. Pending request list.
1. Email list sent to customers.

== Changelog ==

= 1.2.1 =
* Timezone fix.

= 1.2.0 =
* Implements the menu in a custom tab in WooCommerce setting.
* Pending requests are now grouped by email by default and show request date.

= 1.1.2 =
* DB Character set fix.

= 1.1.1 =
* Minor styling improvement. Security update.

= 1.1.0 =
* Cancel button is now optional.
* Product variation alert is now optional.
* Minor layout fixes.

= 1.0.0 =
* Initial release.
