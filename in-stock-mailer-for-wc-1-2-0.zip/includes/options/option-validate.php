<?php

if ( ! defined( 'ABSPATH' ) ) exit;

// Fills empty values with default value if exists
function fill_empty_values_default( $input ) {
  	$default_options = ism_default_values();
    foreach ($input as $key => $value) {
      if ( empty($value) && isset($default_options[$key]) ) {
        $input[$key] = $default_options[$key];
      }
    }
    return $input;
}

function ism_validate_options($input) {
  
  if ( ! current_user_can( 'manage_options' ) ) return;

  if ( "reset" === $input['default_settings'] ) {
    delete_option( 'ism_stock_alert_options' );
    add_settings_error(
        'ism_stock_alert_options', // Setting slug
        'success_message',
        'All settings have been reset!',
        'success'
    );
    return false;
  }

  $err_msg = '';
  $options = get_option( 'ism_stock_alert_options', ism_default_values() );

  foreach (array( 'ism_button_text', 'ism_button_text_cancel' ) as $value) {
    if ( isset($input[$value]) ) {
      $text = $input[$value];
      if ( strlen($text) > ism_get_text_length($value) ) {
        $input[$value] = isset( $options[$value] ) ? $options[$value] : '';
        $err_msg .= __('Button text exceeds 42 characters <br>', ISM_DOMAIN);
      }
    }
  }

  foreach (array( 'ism_button_color', 'ism_button_text_color' ) as $value) {
    if ( isset($input[$value]) ) {
      $input[$value] = $color = sanitize_hex_color( $input[$value] );
      if ( empty($color) ) {
        $input[$value] = isset( $options[$value] ) ? $options[$value] : '';
        $err_msg .= __('Color value is not valid. <br>', ISM_DOMAIN);
      }
    }
  }

  foreach (array( 'ism_button_individual_variation', 'ism_button_cancel_active' ) as $value) {
    if ( isset($input[$value]) ) {
      $input[$value] = rest_sanitize_boolean( $input[$value] );
    }
  }

  if ( isset($input['ism_email_header_img_url']) && !empty($input['ism_email_header_img_url']) ) {
    $input['ism_email_header_img_url'] = $url = wp_http_validate_url($input['ism_email_header_img_url']);
    if ( !$url ) {
      $input['ism_email_header_img_url'] = isset( $options['ism_email_header_img_url'] ) ? $options['ism_email_header_img_url'] : '';
      $err_msg .= __('The email header image Url is not valid. <br>', ISM_DOMAIN);
    }
  }

  if ( isset($input['ism_email_subject']) ) {
    $text = $input['ism_email_subject'];
    if ( strlen($text) > ism_get_text_length('ism_email_subject') ) {
      $input['ism_email_subject'] = isset( $options['ism_email_subject'] ) ? $options['ism_email_subject'] : '';
      $err_msg .= __('The email subject exceeds 65 characters <br>', ISM_DOMAIN);
    }
  }

  if ( isset($input['ism_email_body']) ) {
    $text = $input['ism_email_body'];
    if ( strlen($text) > ism_get_text_length('ism_email_body') ) {
      $input['ism_email_body'] = isset( $options['ism_email_body'] ) ? $options['ism_email_body'] : '';
      $err_msg .= __('The email body text exceeds 254 characters <br>', ISM_DOMAIN);
    }
  }

  if ( !empty( $err_msg ) ) {
    add_settings_error(
        'ism_stock_alert_options', // Setting slug
        'error_message',
         $err_msg,
        'error'
    );
  }

  return fill_empty_values_default($input);
}


?>
