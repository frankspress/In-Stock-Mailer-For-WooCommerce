=== In Stock Mailer for WooCommerce ===
Contributors: frankspress
Donate link: https://paypal.me/frankspress
Tags: in stock alert, woocommerce out of stock, woocommerce, woo commerce, email, shop, products, storefront, mailer, wc
Requires at least: 4.9
Tested up to: 5.3.2
Stable tag: 1.0.0
WC requires at least: 3.5
WC tested up to: 3.9
Requires PHP: 5.6.40
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

In Stock Mailer for WC automatizes the process of sending in stock alert emails to customers with customizable alert button and content.

== Description ==
<p>
Thank you for trying this WP plugin! <br>
This WooCommerce extension allows your online store to have a customizable in stock alert button and email.
If a product or product variation is out of stock this plugin will display an animated button
with a "Notify when available" option.
Registered users can simply click on the button and will be automatically notified by email when the product/s is back in stock.
For optimal customer experience, non-registered users/visitors will be prompted to enter their email address only once since it will be saved in a cookie;
Once a product or more products become available, the application will check and group the requests by email address, and send one email per customer, including images and links
to the product pages they were initially interested in. <br>
In the admin pages you can see the pending alert requests and email sent to customers, sort by date, users and status or group requests by email address.
You can also customize your back in stock email, which will always begin with "Hello {customer name},";
You can choose a custom header image that shows in the top of the email, a custom subject and even modify the body of the email.
</p>
<h3>Notes</h3>
<p>It's important to understand that this plugin uses cookies. This means it's your responsibility to
  abide to any laws and regulations within your country or jurisdiction  ( such as EU Cookie laws ). </p>

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Go to Settings->In Stock Mailer for WC screen to configure the plugin
1. Set up your button text and email header image.
1. Test your email functionality at the bottom of the General Settings page.

== Frequently Asked Questions ==

= Do I have to configure anything to use it? =
Yes and no. The plugin works out of the box but you should add an header image to your email.

= When are the in stock email alerts sent? =
Normally it runs at intervals of 8 hours. If your website has a low traffic rate consider adding a server based cron job.

= Is there any extra futures? =
At the moment there isn't any paid option available.
Depending on requests and feedbacks I will be happy to add new free features in the future! Please hit me up with suggestions.

= The plugin isn't sending any email, what do I do? =
If emails are not being sent the first step is to send an email test. You can do so from the General Settings page.
This plugin requires you to have a transactional email service in place already!

= What is a transactional mail service? =
 It's a service offered by a company that allows WordPress to send "individual emails".
 There are many out there such as SendGrid, mailgun etc.; Some of which have free plans too.

= Will I get spam requests? =
  The plugin offers some degree of protection against spam! Bots will have a hard time sending fake requests but some may get through.
  In the future I might implement captcha if needed/requested.

== Screenshots ==

1. Notification button.
1. General settings menu.
1. Pending request list.
1. Email list sent to customers.

== Changelog ==

= 1.0.0 =
* Initial release.
