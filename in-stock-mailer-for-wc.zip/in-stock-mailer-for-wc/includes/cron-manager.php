<?php

if ( ! defined( 'ABSPATH' ) ) exit;

// REGISTERS WP_CRON INTERVAL
function wp_cron_intervals($schedules) {
  if (!isset($schedules['three_daily'])) {
    // 8 hours intervals
    $three_daily_cron = ['interval'=> 28800,
                         'display' => 'Three times daily'];

    $schedules['three_daily'] = $three_daily_cron;
  }
  return $schedules;
}
add_filter('cron_schedules', 'wp_cron_intervals');


// ADDS WP_CRON EVENT that FIRES after wp_loaded
add_action( 'in_stock_email_event', array('inStockManager', 'emailRequestsAsync'));


?>
