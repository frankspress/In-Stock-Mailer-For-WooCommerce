<?php

if ( ! defined( 'ABSPATH' ) ) exit;


function ism_add_general_settings() {

        add_settings_section(
                'ism_button_settings',
                'Button Settings',
                'ism_description',
                'in-stock-mailer' );

        add_settings_section(
                'ism_email_settings',
                'Email Settings',
                'ism_description',
                'in-stock-mailer' );

        // Button Settings
        add_settings_field(
                'ism_button_text',
                '',
                'ism_callback_field_text',
                'in-stock-mailer',
                'ism_button_settings',
                ['id'=>'ism_button_text',
                 'label'=> 'Notification Text',
                 'description'=> 'This will appear on the "notify when available" button.'] );

        add_settings_field(
               'ism_button_text_cancel',
               '',
               'ism_callback_field_text',
               'in-stock-mailer',
               'ism_button_settings',
               ['id'=>'ism_button_text_cancel',
                'label'=> 'Signed up Text',
                'description'=> 'This will appear on the button on success.'] );

        add_settings_field(
               'ism_button_color',
               '',
               'ism_callback_color_picker',
               'in-stock-mailer',
               'ism_button_settings',
               ['id'=>'ism_button_color',
                'label'=> 'Button Color',
                'description'=> 'The color of the button.'] );

        add_settings_field(
               'ism_button_text_color',
               '',
               'ism_callback_color_picker',
               'in-stock-mailer',
               'ism_button_settings',
               ['id'=>'ism_button_text_color',
                'label'=> 'Button Text Color',
                'description'=> 'The color of the text inside the button.'] );


        // Email settings
        add_settings_field(
               'ism_email_header_img_url',
               '',
               'ism_callback_field_text',
               'in-stock-mailer',
               'ism_email_settings',
               ['id'=>'ism_email_header_img_url',
                'label'=> 'Image Header',
                'placeholder'=> 'https://..',
                'description'=> 'You can use a custom image in your email header.<br>
                Please go to Media -> Library -> Add New, copy and paste the link in this field.<br>
                It\'s highly suggested to use an image size of <b>600 X 300 px</b>.'] );

        add_settings_field(
               'ism_email_subject',
               '',
               'ism_callback_field_text',
               'in-stock-mailer',
               'ism_email_settings',
               ['id'=>'ism_email_subject',
                'label'=> 'Email Subject',
                'description'=> 'The email subject. Make this stand out and catch your customer\'s eyes'] );

        add_settings_field(
               'ism_email_body',
               '',
               'ism_callback_field_textarea',
               'in-stock-mailer',
               'ism_email_settings',
               ['id'=>'ism_email_body',
                'label'=> 'Email Body',
                'description'=> 'The email body starts with "Hello {customer name}," ( if present ),<br>
                followed by this block that you can customize as you wish.<br>
                No links are allowed in this field.'] );
}


?>
