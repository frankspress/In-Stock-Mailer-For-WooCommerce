<?php

if ( ! defined( 'ABSPATH' ) ) exit;

function ism_callback_field_text( $args ) {

	$options = get_option( 'ism_stock_alert_options', ism_default_values() );
	$id    = isset( $args['id'] )    ? $args['id']    : '';
	$label = isset( $args['label'] ) ? $args['label'] : '';
  $placeholder = isset( $args['placeholder'] ) ? $args['placeholder'] : '';
	$description = isset( $args['description'] ) ? $args['description'] : '';
	$value = isset( $options[$id] ) ? sanitize_text_field( $options[$id] ) : ''; ?>

  <tr valign="top">
    <th scope="row"><?php echo $label; ?></th>
    <td>
        <input id="ism_stock_alert_options_<?php echo $id; ?>" name="ism_stock_alert_options[<?php echo $id; ?>]"
               placeholder="<?php echo $placeholder; ?>" type="text" size="50" maxlength="<?php echo esc_attr(ism_get_text_length($id)) ?>" value="<?php echo $value; ?>"><br />
        <p class="description"><?php echo $description; ?></p>
    </td>
  </tr>
  <?php
}

function ism_callback_field_textarea( $args ) {

	$options = get_option( 'ism_stock_alert_options', ism_default_values() );

	$id    = isset( $args['id'] )    ? $args['id']    : '';
	$label = isset( $args['label'] ) ? $args['label'] : '';
	$description = isset( $args['description'] ) ? $args['description'] : '';
	$allowed_tags = wp_kses_allowed_html( 'post' );

	$value = isset( $options[$id] ) ? wp_kses( stripslashes_deep( $options[$id] ), $allowed_tags ) : '';
  $value = trim( preg_replace( '/\h+/', ' ',  $value )  );

  ?>

  <tr valign="top">
    <th scope="row"><?php echo $label; ?></th>
    <td>
        <textarea id="ism_stock_alert_options_<?php echo $id; ?>" name="ism_stock_alert_options[<?php echo $id; ?>]" rows="5" cols="53" maxlength="<?php echo esc_attr(ism_get_text_length($id));?>"><?php echo $value; ?></textarea><br />
        <p class="description"><?php echo $description; ?></p>
    </td>
  </tr>
  <?php
}

function ism_callback_color_picker( $args ) {

  $options = get_option( 'ism_stock_alert_options', ism_default_values() );

	$id    = isset( $args['id'] )    ? $args['id']    : '';
	$label = isset( $args['label'] ) ? $args['label'] : '';
	$description = isset( $args['description'] ) ? $args['description'] : '';
	$value = isset( $options[$id] ) ? sanitize_hex_color( $options[$id] ) : '';
  ?>
  <tr valign="top">
    <th scope="row"><?php echo $label; ?></th>
    <td>
      <input id="ism_stock_alert_options_<?php echo $id; ?>" name="ism_stock_alert_options[<?php echo $id; ?>]"  type="text" value="<?php echo $value; ?>" class="my-color-field"
      data-default-color="<?php echo sanitize_hex_color(ism_default_values()[$id]); ?>" />
      <p class="description"><?php echo $description; ?></p>
    </td>
  </tr>
  <?php
}


function ism_send_test_email_to_field() {
?>
  <table class="form-table" role="presentation">
    <tbody>
        <tr valign="top">
          <th scope="row">Recipent</th>
          <td>
              <input id="recipient_email_field" name="recipient_email_field" type="email" size="50" value="" placeholder="Your email.." required><br />
              <p class="description">Type in your email and check if you receive the test email.<br>
              If the test is successful the application is all set! <br>
              <i>( Please remember to check your spam folder )</i></p>
          </td>
        </tr>
      </tbody>
  </table>

  <?php
}

function ism_description() {
  // LEAVE BLANK
}










 ?>
