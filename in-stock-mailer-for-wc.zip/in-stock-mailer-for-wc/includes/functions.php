<?php

if ( ! defined( 'ABSPATH' ) ) exit;


  function sort_links_asc_desc( $order_by ) {
    $is_desc = $is_asc = '';
    if ( isset($_GET['orderby']) &&
          $_GET['orderby'] == $order_by &&
              !empty($_GET['order']) ) {

      switch ($_GET['order']) {
        case 'desc':
            $is_desc = 'sort-select';
            break;
        case 'asc':
            $is_asc = 'sort-select';
            break;
      }

    }
    $links  = '<a href="' . add_query_arg( array( 'orderby' => $order_by, 'order' => 'desc') ).'"><i class="sort-by-desc '.$is_desc.'"></i></a>';
    $links .= '<a href="' . add_query_arg( array( 'orderby' => $order_by, 'order' => 'asc') ).'"><i class="sort-by-asc '.$is_asc.'"></i></a>';
    return $links;
  }

  function ism_default_values() {
    return array(
        'ism_button_text' => 'Notify me when available',
        'ism_button_text_cancel' => 'You will be notified when available!',
        'ism_button_color' => '#007600',
        'ism_button_text_color' => '#ffffff',
        'ism_email_header_img_url' => '',
        'ism_email_subject' => esc_html( get_bloginfo('name') ) . ' - Back in stock alert!',
        'ism_email_body' => 'Good news!!!
                              We recently got back in stock some of the products you were interested in!',
    );
  }

  function ism_get_text_length($id) {
    $text_lengths = array(
          'ism_button_text' => 50,
          'ism_button_text_cancel' => 50,
          'ism_email_header_img_url' => 450,
          'ism_email_subject' => 65,
          'ism_email_body' => 154,
      );
    return isset($text_lengths[$id]) ? $text_lengths[$id] : '';
  }

?>
